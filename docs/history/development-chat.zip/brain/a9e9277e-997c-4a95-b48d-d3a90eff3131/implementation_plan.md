# Реализация всех улучшений UltraArch Studio

## Обзор

Полная реализация всех 40+ пунктов из [proposals.md](file:///Users/kirich/.gemini/antigravity/brain/a9e9277e-997c-4a95-b48d-d3a90eff3131/proposals.md). Работа разбита на 5 параллельных батчей для максимальной скорости.

---

## Batch 1 — Критические баги (6 файлов)

### [MODIFY] [TaskMatrixGenerator.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/TaskMatrixGenerator.cpp)
- **Баг:** `estimateMemoryMB` (L6-53) перезаписывает `dictSizeMB` вместо суммирования для multi-stream BCJ2
- **Фикс:** Суммировать словари всех потоков (`-m0`, `-m1`, `-m2`, `-m3`), добавить множитель на кол-во потоков
- Добавить `-mmt=N` флаг в генерируемые задачи (Уровень 4.5)
- Добавить solid block size варианты `-ms=` (Уровень 2.6)
- Добавить шифрование `-p` / `-mhe=on` (Уровень 2.3)
- Реализовать smart test skipping на основе анализа контента (Уровень 4.6)
- Реализовать адаптивное сокращение матрицы с quick probe (Уровень 2.2)
- Dictionary auto-tuning на основе RAM/input size (Уровень 4.4)

### [MODIFY] [OptimizerEngine.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/OptimizerEngine.cpp)
- **Баг:** Data race — `m_results[i]` модифицируется без `m_mutex` (L288-330)
- **Фикс:** Блокировать `m_mutex` при записи в `m_results`
- **Баг:** `skipCurrent()` не передаёт cancel token процессу
- **Фикс:** Добавить `m_currentProcessCancelToken` (atomic), передавать в `ProcessManager::execute`, сигналить при skip
- Реализовать параллельный пул воркеров (Уровень 1.1): `std::vector<std::thread>` + task queue + condition_variable
- Реализовать no-double-compression (Уровень 2.1): если SFX не нужен → rename cand_X.7z → output
- Реализовать adaptive matrix pruning (Уровень 2.2): quick probe 1% → intermediate 10% → full run
- Интеграция PreprocessorPipeline (Уровень 1.2)
- Интеграция SessionManager для checkpoint/resume (Уровень 2.5)
- Интеграция ArchiveExtractor для repack mode (Уровень 2.4)
- ETA расчёт (Уровень 3.3)
- Проверка свободного места перед стартом (Уровень 5.1)

### [MODIFY] [OptimizerEngine.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/OptimizerEngine.hpp)
- Добавить: `std::atomic<bool> m_currentSkipToken`, `std::condition_variable m_taskCV`, `std::queue<int> m_pendingTasks`
- Добавить: `double getEstimatedTimeRemaining()`, `SessionManager`, `PreprocessorPipeline` members
- Добавить: ETA tracking members

### [MODIFY] [ProcessManager.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ProcessManager.cpp)
- **Баг:** POSIX zombie — `kill(SIGTERM)` без `waitpid()` (L352)
- **Фикс:** Добавить `waitpid(pid, &status, 0)` после kill
- **Баг:** Windows `quoteArg` — trailing backslash ломает кавычки (L23-35)
- **Фикс:** Escape trailing backslashes перед закрывающей кавычкой
- POSIX resource guard: добавить `setrlimit()` для памяти, `sched_setaffinity()` для CPU

### [MODIFY] [ContentAnalyzer.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ContentAnalyzer.cpp)
- **Баг:** Integer overflow в PE offset check (L42), unaligned read (L42)
- **Фикс:** `memcpy` вместо `reinterpret_cast`, проверка `peOffset < bytesRead - 4`
- Кэширование анализа (Уровень 4.3): сохранение/загрузка `{path, size, mtime} → {category, entropy}` в JSON
- Параллельное сканирование через thread pool

### [MODIFY] [ResourceGuard.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ResourceGuard.cpp)
- **Баг:** Single-core affinity bottleneck (L80) — 7z зажат на 1 ядро
- **Фикс:** Для N воркеров → выделять `physicalCores/N` ядер каждому воркеру
- Поддержка >64 процессоров (Processor Groups)
- Отдельный Job Object на каждого воркера

---

## Batch 2 — Новые классы и инфраструктура (11 новых файлов)

### [NEW] [PreprocessorPipeline.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/PreprocessorPipeline.hpp)
### [NEW] [PreprocessorPipeline.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/PreprocessorPipeline.cpp)
Пайплайн предобработки: `Precomp → Leanify → ECT → 7z`
- Класс `PreprocessStep` (имя, exe path, аргументы, applicable file types)
- Класс `PreprocessorPipeline` с цепочкой шагов
- Метод `execute(inputDir, tempDir, cancelToken)` → модифицированный inputDir
- Отдельная статистика: размер до/после каждого шага
- Автоопределение доступных инструментов

### [NEW] [SessionManager.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/SessionManager.hpp)
### [NEW] [SessionManager.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/SessionManager.cpp)
Checkpoint/Resume система:
- Сохранение в `session.json`: настройки, completed tasks, results, leader index
- `saveCheckpoint()` — после каждого завершённого кандидата
- `tryResumeSession(inputPath)` — поиск совместимой сессии
- `clearSession()` — удаление при завершении
- История сессий (Уровень 5.4)

### [NEW] [ArchiveExtractor.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ArchiveExtractor.hpp)
### [NEW] [ArchiveExtractor.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ArchiveExtractor.cpp)
RePack Mode — распаковка входных архивов:
- Автоопределение формата (7z, ZIP, RAR, tar.gz, tar.xz) по magic bytes
- Распаковка во временную директорию через `7z x`
- Метрики: исходный размер архива vs результат

### [NEW] [PresetManager.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/PresetManager.hpp)
### [NEW] [PresetManager.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/PresetManager.cpp)
Сохранение/загрузка пресетов:
- JSON формат с полным `OptimizerSettings`
- Встроенные пресеты: "Game RePack", "ISO Archive", "Source Code", "Photo Archive"
- Portable mode: хранение рядом с exe или в AppData
- Import/Export

### [NEW] [Localization.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/Localization.hpp)
Система локализации EN/RU:
- `enum class Lang { EN, RU }`
- `static const char* tr(StringId id)` — перевод по ID
- Все UI-строки через `L::tr()`

### [MODIFY] [Types.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/Types.hpp)
Расширение структур:
- `OptimizerSettings`: добавить `password`, `encryptHeaders`, `volumeSizeMB`, `solidBlockSize`, `enablePreprocessors`, `enableAdaptivePruning`, `pruningThreshold`, `quickProbePercent`
- `CandidateResult`: добавить `errorCode` enum
- `EngineState`: добавить `Preprocessing`, `Extracting`
- Новый `struct SessionInfo` для checkpoint/resume
- `struct PreprocessStats` для пайплайна

### [MODIFY] [ArchiveAssembler.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/ArchiveAssembler.cpp)
- Реализовать smart categorized solid assembly (Уровень 1.3):
  - Генерация listfile с сортировкой по категории
  - Группировка в solid blocks по типу
  - `-mx0` для precompressed
- Multi-volume: флаг `-v{size}m`
- SFX проверка наличия модуля перед добавлением `-sfx`
- Fix wildcard/path separator на Windows

### [MODIFY] [EmbeddedTools.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/core/EmbeddedTools.cpp)
- Thread-safety: `std::call_once` вместо static bool
- SHA-256 верификация вместо проверки размера
- Configurable timeout вместо hardcoded 10s
- SREP binary support

---

## Batch 3 — UI/UX (4 файла + 1 новый)

### [MODIFY] [MainWindow.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/MainWindow.hpp)
- Добавить: preset selector, encryption fields, volume size, hotkey handling
- Добавить: ETA display, confirmation dialog state, settings lock flag
- Увеличить path buffers до 2048

### [MODIFY] [MainWindow.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/MainWindow.cpp)
- Native file dialogs: `IFileOpenDialog` COM (Win32) / nfd (cross-platform)
- Кнопка `[📂]` рядом с каждым полем пути
- Drag & Drop визуальная зона
- ETA отображение: "Осталось ~2ч 15мин (12/48)"
- Encryption UI: поле пароля + checkbox "Encrypt headers"
- Volume size selector
- Preset dropdown с save/load/delete
- Settings lock при активной оптимизации (disable sliders)
- Confirmation dialog при Cancel
- Горячие клавиши (Ctrl+S, Esc, Space)
- "Что-если" кнопка — показ матрицы без запуска
- Показ итоговой 7z-команды
- Проверка свободного места перед стартом

### [MODIFY] [LeaderboardWidget.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/LeaderboardWidget.cpp)
- Реальная сортировка: `ImGuiTableFlags_Sortable` по всем колонкам
- Контекстное меню: "Копировать флаги", "Перезапустить", "Выбрать победителем"
- Экспорт в CSV/JSON
- Цветовой градиент строк
- Замена deprecated `ImGui::Columns()` на `ImGui::BeginTable()`

### [MODIFY] [TelemetryWidget.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/TelemetryWidget.cpp)
- Реальный Storage I/O: `GetProcessIoCounters()` (Win), `proc_pidinfo` (macOS)
- Реальная POSIX телеметрия: `/proc/stat`, `sysctl`, `host_statistics`
- Ring buffer вместо `vector.erase(begin())` — O(1) вместо O(N)
- Динамический масштаб графика Disk I/O
- Замена deprecated `ImGui::Columns()` на `ImGui::BeginTable()`

### [MODIFY] [Theme.hpp](file:///Users/kirich/Desktop/7zOptimizer/src/ui/Theme.hpp)
- Загрузка шрифтов Segoe UI / Inter
- Light theme
- DPI-aware scaling function
- Анимации переходов

### [MODIFY] [main.cpp](file:///Users/kirich/Desktop/7zOptimizer/src/main.cpp)
- Win32: `DragAcceptFiles(hwnd, TRUE)` + `WM_DROPFILES` handler
- Win32: `WM_DPICHANGED` handler
- Win32: System Tray (`Shell_NotifyIcon`) + Toast notifications
- CLI: `try/catch` для `stoul`/`stoull`
- CLI: валидация `--profile`
- VSync toggle когда приложение свёрнуто (экономия GPU)
- Auto-shutdown option (`shutdown /s /t 60`)

---

## Batch 4 — Тесты

### [MODIFY] [TestMain.cpp](file:///Users/kirich/Desktop/7zOptimizer/tests/TestMain.cpp)
Новые тесты:
- `testMultiStreamMemoryEstimation` — BCJ2 4-stream суммирование
- `testPeParserSafety` — overflow/unaligned read
- `testSmartSkipping` — пропуск BCJ для не-PE данных
- `testAdaptivePruning` — логика отсечения
- `testSolidBlockVariants` — генерация `-ms=` флагов
- `testEncryptionFlags` — `-p` и `-mhe=on`
- `testPresetSaveLoad` — JSON round-trip
- `testSessionCheckpoint` — save/resume
- `testArchiveDetection` — magic bytes для входных архивов
- `testDictionaryAutoTuning` — формула auto-dict
- RAII cleanup для temp файлов (fix утечки)

---

## Batch 5 — Build System

### [MODIFY] [CMakeLists.txt](file:///Users/kirich/Desktop/7zOptimizer/CMakeLists.txt)
- Добавить новые source files (PreprocessorPipeline, SessionManager, ArchiveExtractor, PresetManager, Localization)
- `find_package(Threads REQUIRED)` + `target_link_libraries(Threads::Threads)` для Linux/macOS
- Добавить `shlwapi` и `uxtheme` для Windows
- Условная компиляция UI sources только когда GUI доступен

### [MODIFY] [tests/CMakeLists.txt](file:///Users/kirich/Desktop/7zOptimizer/tests/CMakeLists.txt)
- Добавить новые core source files
- Линковка `psapi` и Windows system libraries

---

## Порядок выполнения

```mermaid
flowchart LR
    B1["Batch 1\nБаги + Рефакторинг ядра\n(параллельно)"] --> B2["Batch 2\nНовые классы\n(параллельно)"]
    B2 --> B3["Batch 3\nUI/UX\n(параллельно)"]
    B1 --> B5["Batch 5\nBuild System"]
    B3 --> B4["Batch 4\nТесты"]
    B5 --> B4
```

> [!IMPORTANT]
> Batch 1 (баги) идёт первым — все остальные батчи зависят от исправленного ядра.
> Batches 2 и 3 могут частично параллелиться (новые классы не зависят от UI).

## Верификация

### Автоматические тесты
```bash
cd /Users/kirich/Desktop/7zOptimizer/build
cmake .. && cmake --build . && ctest --output-on-failure
```

### End-to-End тест
```bash
./UltraArchStudio --cli --input test_data/ --output result.7z --temp /tmp/test --profile extreme
7zz t result.7z
```

---

Подтвердите план, и я начну реализацию всех батчей параллельно.

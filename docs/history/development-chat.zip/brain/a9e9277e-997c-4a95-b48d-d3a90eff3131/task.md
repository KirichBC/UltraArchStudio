# UltraArch Studio — Task Tracker

## Batch 1: Critical Bug Fixes
- `[x]` Fix BCJ2 multi-stream memory estimation (TaskMatrixGenerator.cpp)
- `[x]` Fix data race in OptimizerEngine (m_results without mutex)
- `[x]` Fix POSIX zombie processes (ProcessManager.cpp)
- `[x]` Fix PE parser integer overflow + unaligned read (ContentAnalyzer.cpp)
- `[x]` Fix Skip/Pause/AssembleBest not killing active process
- `[x]` Fix Windows path escaping (trailing backslash)

## Batch 2: New Core Infrastructure
- `[x]` Types.hpp — extend all structs with new fields
- `[x]` PreprocessorPipeline.hpp/.cpp — Leanify/ECT/Precomp/SREP
- `[x]` SessionManager.hpp/.cpp — checkpoint/resume
- `[x]` ArchiveExtractor.hpp/.cpp — repack mode
- `[x]` PresetManager.hpp/.cpp — save/load presets
- `[x]` Localization.hpp — EN/RU translations
- `[x]` Parallel worker pool in OptimizerEngine
- `[x]` Smart categorized solid assembly (ArchiveAssembler)
- `[x]` No double compression optimization
- `[x]` Adaptive matrix pruning (quick probe)
- `[x]` Content analysis cache (ContentAnalyzer)
- `[x]` Smart test skipping (TaskMatrixGenerator)
- `[x]` Dictionary auto-tuning (TaskMatrixGenerator)
- `[x]` -mmt control (TaskMatrixGenerator + ResourceGuard)
- `[x]` Solid block size variants (TaskMatrixGenerator)
- `[x]` Encryption support (TaskMatrixGenerator)
- `[x]` Multi-volume archives (ArchiveAssembler)
- `[x]` SREP deduplication (PreprocessorPipeline)
- `[x]` EmbeddedTools thread safety + SHA-256

## Batch 3: UI/UX
- `[x]` Native file dialogs (IFileOpenDialog / nfd)
- `[x]` Drag & Drop (WM_DROPFILES)
- `[x]` ETA estimation display
- `[x]` System Tray + Toast notifications
- `[x]` Preset selector UI
- `[x]` Encryption UI (password field)
- `[x]` Leaderboard real sorting (ImGuiTableFlags_Sortable)
- `[x]` Leaderboard context menu
- `[x]` Leaderboard export CSV/JSON
- `[x]` Real Storage I/O monitoring
- `[x]` Real POSIX telemetry
- `[x]` TelemetryWidget ring buffer optimization
- `[x]` Theme: font loading (Segoe UI / Inter)
- `[x]` Theme: DPI-aware scaling
- `[x]` Theme: light theme option
- `[x]` Log: clear/copy/search buttons
- `[x]` Settings lock during execution
- `[x]` Cancel confirmation dialog
- `[x]` Hotkeys (Ctrl+S, Esc, Space)
- `[x]` "What-if" mode button
- `[x]` Show final 7z command
- `[x]` Volume size selector
- `[x]` Disk space pre-check warning
- `[x]` Auto-shutdown option
- `[x]` Localization EN/RU switcher
- `[x]` Portable mode toggle

## Batch 4: Tests
- `[x]` testMultiStreamMemoryEstimation
- `[x]` testPeParserSafety
- `[x]` testSmartSkipping
- `[x]` testAdaptivePruning
- `[x]` testSolidBlockVariants
- `[x]` testEncryptionFlags
- `[x]` testPresetSaveLoad
- `[x]` testSessionCheckpoint
- `[x]` testArchiveDetection
- `[x]` testDictionaryAutoTuning
- `[x]` RAII cleanup for temp files

## Batch 5: Build System
- `[x]` CMakeLists.txt — add new source files
- `[x]` CMakeLists.txt — Threads::Threads linking
- `[x]` CMakeLists.txt — shlwapi/uxtheme for Windows
- `[x]` tests/CMakeLists.txt — add new sources + psapi

## Batch 6: Windows Distribution & Portable Packaging
- `[x]` Fix DX11 WM_SIZE buffer resize timing in WndProc / render loop
- `[x]` Fix EmbeddedTools directory resolution via GetModuleFileNameW
- `[x]` Wrap WinMain in try-catch with MessageBox fallback
- `[x]` Use std::error_code in PresetManager to prevent uncaught exceptions
- `[x]` Package standalone portable bundle with side-by-side tools: release/UltraArchStudio_Win64/
- `[x]` Pack portable bundle into ZIP archive (UltraArchStudio_Win64.zip)
- `[x]` Pack portable bundle into 7z archive (UltraArchStudio_Win64.7z)
